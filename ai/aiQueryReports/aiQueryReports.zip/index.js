const { DuckDBInstance } = require('@duckdb/node-api');

exports.handler = async (event) => {
    try {
        const instance = await DuckDBInstance.create(':memory:');
        const connection = await instance.connect();

        // FIX: Force DuckDB to use Lambda's ONLY writable folder for downloading extensions
        await connection.run("SET home_directory='/tmp';");

        // Now downloading and loading httpfs will succeed smoothly
        await connection.run("INSTALL httpfs;");
        await connection.run("LOAD httpfs;");

        // Set up your S3 credentials
        await connection.run(`
            CREATE SECRET s3_credentials (
                TYPE S3,
                PROVIDER CREDENTIAL_CHAIN,
                REGION '${process.env.AWS_REGION || 'us-east-2'}'
            );
        `);

        // Execute your S3 queries
        const s3ReadPath = 's3://your-bucket-name/input-data.parquet';
        const reader = await connection.runAndReadAll(`
            SELECT item_name, SUM(price) as total_sales 
            FROM read_parquet('${s3ReadPath}') 
            GROUP BY item_name
        `);
        const rows = reader.getRows();

        const s3WritePath = 's3://your-bucket-name/outputs/sales_summary.parquet';
        await connection.run(`
            COPY (SELECT * FROM read_parquet('${s3ReadPath}')) 
            TO '${s3WritePath}' (FORMAT PARQUET);
        `);

        return {
            statusCode: 200,
            body: JSON.stringify({ 
                message: "S3 Read and Write successful!",
                previewData: rows 
            }),
        };
    } catch (error) {
        return {
            statusCode: 500,
            body: JSON.stringify({ error: error.message }),
        };
    }
};
