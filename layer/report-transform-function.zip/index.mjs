import { S3Client, GetObjectCommand, PutObjectCommand } from '@aws-sdk/client-s3';
import { simpleParser } from 'mailparser';
import { findTransformForFilename } from './registry.mjs';

const s3 = new S3Client({});

const RAW_BUCKET = process.env.RAW_BUCKET;             // e.g. topstepllc-intake-raw
const OUTPUT_BUCKET = process.env.OUTPUT_BUCKET;       // e.g. topstepllc-intake-processed
const UNMATCHED_PREFIX = process.env.UNMATCHED_PREFIX || 'unmatched/';
const OUTPUT_PREFIX = process.env.OUTPUT_PREFIX || 'processed/';

export const handler = async (event) => {
  const ses = event.Records[0].ses;
  const messageId = ses.mail.messageId;
  const rawKey = `raw/${messageId}`;

  console.log(`Processing message ${messageId} from ${ses.mail.commonHeaders?.from}`);

  const rawObj = await s3.send(new GetObjectCommand({ Bucket: RAW_BUCKET, Key: rawKey }));
  const rawEmail = await rawObj.Body.transformToByteArray();

  const parsed = await simpleParser(Buffer.from(rawEmail));
  console.log(`Subject: ${parsed.subject}, attachments: ${parsed.attachments.length}`);

  const results = [];

  for (const att of parsed.attachments) {
    const filename = att.filename || 'unnamed';
    const entry = findTransformForFilename(filename);

    if (!entry) {
      console.log(`No transform registered for "${filename}" - storing as-is for review`);
      const key = `${UNMATCHED_PREFIX}${messageId}/${filename}`;
      await s3.send(new PutObjectCommand({
        Bucket: OUTPUT_BUCKET,
        Key: key,
        Body: att.content,
        ContentType: att.contentType,
      }));
      results.push({ filename, matched: false, outputKey: key });
      continue;
    }

    console.log(`Matched "${filename}" -> transform "${entry.name}"`);

    try {
      const csvText = att.content.toString('utf8');
      const xlsxBuffer = await entry.transform(csvText);
      const outputFilename = entry.outputFilename(filename);
      const key = `${OUTPUT_PREFIX}${messageId}/${outputFilename}`;

      await s3.send(new PutObjectCommand({
        Bucket: OUTPUT_BUCKET,
        Key: key,
        Body: xlsxBuffer,
        ContentType: 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet',
      }));

      console.log(`Wrote transformed report to ${key}`);
      results.push({ filename, matched: true, transform: entry.name, outputKey: key });
    } catch (err) {
      console.error(`Transform "${entry.name}" failed for "${filename}":`, err);
      results.push({ filename, matched: true, transform: entry.name, error: err.message });
    }
  }

  console.log('Summary:', JSON.stringify(results, null, 2));

  return { disposition: 'CONTINUE' };
};
