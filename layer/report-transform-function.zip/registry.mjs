import { transform as byClientRoleTransform } from './transforms/byClientRole.mjs';

/**
 * Add one entry per client-specific report format. `pattern` is tested against
 * the attachment's filename as it arrives on the email (case-insensitive).
 * First match wins, so keep more specific patterns above more general ones.
 */
export const REPORT_REGISTRY = [
  {
    name: 'byClientRole',
    pattern: /^By_ClientRole_Report_1_report.*\.csv$/i,
    transform: (csvText) =>
      byClientRoleTransform(csvText, {
        sheetTitle: 'By Client-Role (report 1)',
        reportLabel: 'Report 1 to download',
      }),
    outputFilename: (originalName) => originalName.replace(/\.csv$/i, '.xlsx'),
  },

  // Add future client formats here, e.g.:
  // {
  //   name: 'byProjectSummary',
  //   pattern: /^By_Project_Summary.*\.csv$/i,
  //   transform: (csvText) => byProjectSummaryTransform(csvText),
  //   outputFilename: (originalName) => originalName.replace(/\.csv$/i, '.xlsx'),
  // },
];

export function findTransformForFilename(filename) {
  return REPORT_REGISTRY.find((entry) => entry.pattern.test(filename));
}
