import { parse } from 'csv-parse/sync';
import ExcelJS from 'exceljs';

const ACCOUNTING_FMT = '_(* #,##0_);_(* \\(#,##0\\);_(* "-"??_);_(@_)';
const USER_INDENT = '          '; // 10 spaces, matches client's expected format

// Colors pulled from the client's mockup theme (xl/theme/theme1.xml) and resolved
// through Excel's tint formula, so this matches their file exactly rather than
// approximating a similar shade.
const HEADER_FILL = 'FFFDFDFD'; // theme "Light 2" (E8E8E8) @ 90% tint - client/Total header row
const DATA_FILL = 'FFD9F2D0';   // theme "Accent 6" (4EA72E) @ 80% tint - populated data cells

/**
 * Parses the "By Client-Role" SPP export into a pivot structure.
 *
 * Source shape (indentation-based hierarchy, no explicit parent/child column):
 *   ClientA,<hours>,<amount>          <- top-level client row (no leading spaces)
 *        UserX,<hours>,<amount>       <- indented user row, belongs to ClientA above
 *        UserY,<hours>,<amount>
 *   ClientB,<hours>,<amount>
 *        UserX,<hours>,<amount>       <- same user can recur under multiple clients
 *    ,<hours>,<amount>                <- grand total row (blank/whitespace name) - ignored
 *   Generated on: ...                 <- footer row - ignored
 */
function parseByClientRole(csvText) {
  // Strip BOM if present
  const clean = csvText.replace(/^\uFEFF/, '');

  const records = parse(clean, {
    columns: false,
    relax_column_count: true,
    skip_empty_lines: true,
  });

  // Row 0 is the report title line, row 1 is the header row ("Client/User,Total - Timesheets...").
  // Everything after that is data until the footer ("Generated on: ...") or the blank-name total row.
  const dataRows = records.slice(2);

  const clients = new Set();
  const users = new Set();
  // pivot[user][client] = { hours, amount }
  const pivot = {};

  let currentClient = null;

  for (const row of dataRows) {
    const rawName = row[0] ?? '';
    const hours = parseFloat(row[1]);
    const amount = parseFloat(row[2]);

    if (/^generated on:/i.test(rawName.trim())) {
      continue; // footer
    }

    if (rawName.trim() === '') {
      continue; // grand total row - we recompute totals via formulas
    }

    const isUserRow = /^\s+/.test(rawName) && rawName !== rawName.trim();
    const name = rawName.trim();

    if (!isUserRow) {
      currentClient = name;
      clients.add(currentClient);
      continue;
    }

    if (!currentClient) {
      // Defensive: a user row appeared before any client row - skip rather than mis-attribute
      continue;
    }

    users.add(name);
    pivot[name] = pivot[name] || {};
    const existing = pivot[name][currentClient] || { hours: 0, amount: 0 };
    pivot[name][currentClient] = {
      hours: existing.hours + (isNaN(hours) ? 0 : hours),
      amount: existing.amount + (isNaN(amount) ? 0 : amount),
    };
  }

  return {
    clients: Array.from(clients).sort((a, b) => a.localeCompare(b)),
    users: Array.from(users).sort((a, b) => a.localeCompare(b)),
    pivot,
  };
}

function colLetter(n) {
  // 1-indexed column number -> letter
  let s = '';
  while (n > 0) {
    const rem = (n - 1) % 26;
    s = String.fromCharCode(65 + rem) + s;
    n = Math.floor((n - 1) / 26);
  }
  return s;
}

/**
 * Builds the target-format workbook (buffer) from parsed pivot data.
 */
async function buildWorkbook({ clients, users, pivot }, { sheetTitle = 'By Client-Role (report 1)' } = {}) {
  const wb = new ExcelJS.Workbook();
  // Force Excel to recalculate on open too, as a second safety net alongside
  // the cached formula results we write below.
  wb.calcProperties.fullCalcOnLoad = true;

  const ws = wb.addWorksheet(sheetTitle);
  ws.getColumn(1).width = 20.33;

  const headerFill = { type: 'pattern', pattern: 'solid', fgColor: { argb: HEADER_FILL } };
  const dataFill = { type: 'pattern', pattern: 'solid', fgColor: { argb: DATA_FILL } };

  // Client header row (row 4) + Hour/Amount sub-header row (row 5)
  // Columns start at C (3): each client gets two columns (Hour, Amount)
  const headerRow = 4;
  const subHeaderRow = 5;
  const firstDataRow = 7;

  let col = 3; // column C
  const clientColStart = {}; // client -> starting column index (Hour column)
  for (const client of clients) {
    clientColStart[client] = col;
    const hourCell = ws.getCell(headerRow, col);
    const amountCell = ws.getCell(headerRow, col + 1);
    hourCell.value = client;
    amountCell.value = client;
    hourCell.font = { bold: true };
    amountCell.font = { bold: true };
    hourCell.fill = headerFill;
    amountCell.fill = headerFill;

    ws.getCell(subHeaderRow, col).value = 'Hour';
    ws.getCell(subHeaderRow, col + 1).value = 'Amount';
    ws.getCell(subHeaderRow, col).font = { bold: true };
    ws.getCell(subHeaderRow, col + 1).font = { bold: true };

    col += 2;
  }

  const totalHourCol = col;
  const totalAmountCol = col + 1;
  ws.getCell(headerRow, totalHourCol).value = 'Total';
  ws.getCell(headerRow, totalAmountCol).value = 'Amount';
  ws.getCell(headerRow, totalHourCol).font = { bold: true };
  ws.getCell(headerRow, totalAmountCol).font = { bold: true };
  ws.getCell(headerRow, totalHourCol).fill = headerFill;
  ws.getCell(headerRow, totalAmountCol).fill = headerFill;
  ws.getCell(subHeaderRow, totalHourCol).value = 'Hour';
  ws.getCell(subHeaderRow, totalAmountCol).value = 'Amount';
  ws.getCell(subHeaderRow, totalHourCol).font = { bold: true };
  ws.getCell(subHeaderRow, totalAmountCol).font = { bold: true };

  // Running grand totals per column, for the Totals row at the bottom
  const colSums = {}; // colIndex -> running sum

  // Data rows: one per user
  let row = firstDataRow;
  for (const user of users) {
    ws.getCell(row, 1).value = USER_INDENT + user;

    let rowHourTotal = 0;
    let rowAmountTotal = 0;

    for (const client of clients) {
      const cellData = pivot[user]?.[client];
      if (cellData) {
        const hourCol = clientColStart[client];
        const amountCol = hourCol + 1;

        const hourCell = ws.getCell(row, hourCol);
        hourCell.value = cellData.hours;
        hourCell.fill = dataFill;

        const amtCell = ws.getCell(row, amountCol);
        amtCell.value = cellData.amount;
        amtCell.numFmt = ACCOUNTING_FMT;
        amtCell.fill = dataFill;

        rowHourTotal += cellData.hours;
        rowAmountTotal += cellData.amount;

        colSums[hourCol] = (colSums[hourCol] || 0) + cellData.hours;
        colSums[amountCol] = (colSums[amountCol] || 0) + cellData.amount;
      }
    }

    const totalHourCell = ws.getCell(row, totalHourCol);
    totalHourCell.value = {
      formula: '+' + clients.map((c) => `${colLetter(clientColStart[c])}${row}`).join('+'),
      result: rowHourTotal,
    };
    totalHourCell.font = { bold: true };

    const totalAmountCell = ws.getCell(row, totalAmountCol);
    totalAmountCell.value = {
      formula: '+' + clients.map((c) => `${colLetter(clientColStart[c] + 1)}${row}`).join('+'),
      result: rowAmountTotal,
    };
    totalAmountCell.font = { bold: true };
    totalAmountCell.numFmt = ACCOUNTING_FMT;

    colSums[totalHourCol] = (colSums[totalHourCol] || 0) + rowHourTotal;
    colSums[totalAmountCol] = (colSums[totalAmountCol] || 0) + rowAmountTotal;

    row += 1;
  }

  // Totals row: one blank row gap after the last data row, matching the mockup
  const totalsRow = row + 1;
  ws.getCell(totalsRow, 1).value = 'Totals:';
  ws.getCell(totalsRow, 1).font = { bold: true };

  const lastDataRow = row - 1;
  for (let c = 3; c <= totalAmountCol; c++) {
    const letter = colLetter(c);
    const cell = ws.getCell(totalsRow, c);
    cell.value = {
      formula: `SUM(${letter}${firstDataRow}:${letter}${lastDataRow + 1})`,
      result: colSums[c] || 0,
    };
    cell.font = { bold: true };
    if (c === totalAmountCol || (c >= 3 && (c - 3) % 2 === 1)) {
      // Amount columns (odd offset from C) get accounting format
      cell.numFmt = ACCOUNTING_FMT;
    }
  }

  return wb.xlsx.writeBuffer();
}

export async function transform(csvText, options) {
  const parsed = parseByClientRole(csvText);
  return buildWorkbook(parsed, options);
}

export { parseByClientRole, buildWorkbook };
